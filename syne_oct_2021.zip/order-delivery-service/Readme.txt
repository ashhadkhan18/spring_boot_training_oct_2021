1) Spring boot starter project 
2) Add  lombok,mysql,web,configclient,actuator,spring data jpa
3) create a entity class Order 
4) Create a inteface OrderRepository extending JPARepository
5) Create a Class OrderService
6) Create a Class OrderController
7) Add the required entries in the classes and interfaces
8) update the github repository 
9) Create a file order-delivery-service/application.yml
10) Add Entries to the application.yml
11) Restart the Config Server
12) Start order-service project
